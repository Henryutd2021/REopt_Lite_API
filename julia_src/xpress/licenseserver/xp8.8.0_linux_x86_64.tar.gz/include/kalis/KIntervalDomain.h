// ********************************************************************
// * Artelys Kalis                                                    *
// * Copyright (C) 2001-2016 by Artelys                               *
// * All Rights Reserved                                              *
// *                                                                  *
// * File : KIntervalDomain.h                                         *
// ********************************************************************

#ifndef __KINTERVALDOMAIN_H
#define __KINTERVALDOMAIN_H

#include "Globals.h"
#include "KBranchingScheme.h"
#include "kalis_compat.h"

class  DLLIMPORTEXPORT KIntervalDomain : public KBranchingScheme  {

  public:
    //constructor
    KIntervalDomain(const KNumVarArray& floatVarArray, double gap, bool order);
    // Constructor with KIntervalDomain_I*
    KIntervalDomain(KIntervalDomain_I* intervalDomain);
    //destructor
    virtual ~KIntervalDomain();

    virtual KBranchingScheme* getCopyPtr() const;

    virtual KBranchingScheme* getInstanceCopyPtr(const KProblem& problem) const;


}; // class KIntervalDomain

#endif
