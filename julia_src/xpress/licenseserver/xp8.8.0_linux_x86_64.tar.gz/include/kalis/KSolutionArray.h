// ********************************************************************
// * Artelys Kalis                                                    *
// * Copyright (C) 2001-2016 by Artelys                               *
// * All Rights Reserved                                              *
// *                                                                  *
// * File : KSolutionArray.h                                          *
// * Description : array of solutions                                 *
// ********************************************************************

#ifndef __KSOLUTIONARRAY_H
#define __KSOLUTIONARRAY_H

#include "Globals.h"
#include "ArtelysList.h"
#include "KSolution.h"

EXTTEMPL template class DLLIMPORTEXPORT ArtelysList<KSolution>;

/**
 * An array of KSolution objects
 */
class DLLIMPORTEXPORT KSolutionArray : public ArtelysList<KSolution> {
  public:
    /// Constructor
    KSolutionArray();
    /// Variable arguments list constructor
#ifndef VARARGIGNORE
    KSolutionArray(int nbOfElt, ...);
#endif
    // Destructor
    virtual ~KSolutionArray();
}; // class KSolutionArray

#endif


