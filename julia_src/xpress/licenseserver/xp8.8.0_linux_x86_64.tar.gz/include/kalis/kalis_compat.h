// ********************************************************************
// * Artelys Kalis                                                    *
// * Copyright (C) 2001-2016 by Artelys                               *
// * All Rights Reserved.                                             *
// ********************************************************************

#ifndef COMPATIBILITY_H
#define COMPATIBILITY_H

#if defined(__linux) && !defined(DISABLE_SYMVER)
__asm__(".symver memcpy, memcpy@GLIBC_2.2.5");
#endif

#ifdef _MSC_VER
#  define stricmp _stricmp
#endif

#endif
