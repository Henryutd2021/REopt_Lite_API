/************************/
/*         Mosel        */
/*                      */
/* File  xprm_mc.h      */
/************************/
/* (c) Copyright Fair Isaac Corporation 2001-2011. All rights reserved */

#ifndef _MOSEL_MC_H
#include "xprm_rt.h"
#include "mosel_mc.h"
#endif
