Mosel Examples
==============

This directory is organised as follows:

Distrib
-------
  Examples showing how to use 'mmjobs' to implement distributed models.

Graphing
--------
  Examples of graph drawing with 'mmsvg'.

Extra
-----
  Examples using the XPRD and BinDrv libraries, and the Amazon EC2 interface.

Library
-------
  Several C programs using the Mosel libraries.

Modeling
---------
  A set of introductory examples that show the modeling and basic
  solving features of the Mosel language.
  
Module
------
  Several modules for Mosel written in C.

Programming
-----------
  Several small examples that show how the Mosel language may be
  used for programming in general.

Solving
-------
  Using the more advanced solving features of Mosel to implement
  various solution heuristics and generate nicely formatted output.

WhitePapers
-----------
  Examples from the Mosel Whitepaper documents
  

