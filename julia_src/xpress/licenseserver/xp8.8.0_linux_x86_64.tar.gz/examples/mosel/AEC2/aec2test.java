/*******************************************************
 * Mosel Example Problems                              *
 * ======================                              *
 *                                                     *
 * file aec2test.java                                  *
 * ``````````````````                                  *
 *  A simple program for testing the AEC2 package      *
 *                                                     *
 * (c) 2011 Fair Isaac Corporation                     *
 *     author: Y. Colombani                            *
 *******************************************************/

import java.util.*;
import java.util.logging.*;
import java.lang.*;
import java.io.*;
import com.dashoptimization.*;

public class aec2test
{
 public static void main(String[] args) throws Exception
 {
  AEC2 aec2=new AEC2();
  List<AEC2Instance> instances;
  AEC2Instance ainst;
  byte buf[]=new byte[80];

  XPRD xprd=new XPRD();
  XPRDMosel minst;
  XPRDModel rmod;

  // Load config and make AWS silent
  aec2.loadConfig("aec2.acf");
  LogManager.getLogManager().getLogger("com.amazonaws.request").setLevel(Level.WARNING);

  // Let's try to find a running instance
  ainst=null;
  instances=aec2.getAllInstances();
  if(instances.size()>0)
  {
   System.out.println("+ Found the following running instance(s):");
   for(Iterator<AEC2Instance> itm=instances.iterator();itm.hasNext();)
   {
    AEC2Instance i=itm.next();
    System.out.println("\t"+i.getId()+"("+i.statetext()+") from image "+i.image);
    if((ainst==null)&& (i.state==i.RUNNING))
     ainst=i;
   }
   if(ainst==null)
    System.out.println("None of these instances can be used");
  }
  else
   System.out.println("+ No instance running.");
  System.out.println();

  if(ainst==null)
  {
   System.out.print("+ Starting a new EC2 instance.");System.out.flush();
   ainst=aec2.runInstance();
   if(!ainst.waitIsReady(300,true))
   {
    System.out.println("\nFailed to start instance!");
    ainst.terminate();
    System.exit(1);
   }
   System.out.println();
  }

  System.out.println("+ Starting Mosel on instance "+ainst.getId());
  // Start a Mosel instance in the cloud...
  minst=xprd.connect(ainst.getConnString());

  System.out.println("+ Remote instance system information:"+minst.getSystemInformation());
  System.out.println();
  
  // generate a simple model for testing
  PrintStream mexm=new PrintStream("minimod.mos");
  mexm.println(
     "model minimod\n"+
     "writeln('Hello from EC2')\n"+
     "end-model");
  mexm.close();

  System.out.println("+ Compile a model remotely (bim file saved on the remote instance)");
  // Now compile then load...
  minst.compile("","rmt:minimod.mos","tmp:m.bim");

  System.out.println("+ Load then run:");
  rmod=minst.loadModel("tmp:m.bim");
  rmod.run();
  xprd.waitForEvent();
  xprd.dropNextEvent();
  System.out.println("\n+ Execution finished!");
  minst.unloadModel(rmod);

  System.out.println("+ Disconnecting Mosel.");
  minst.disconnect();

  System.out.print("\nWould you like to shut down Amazon instance "+ainst.getId()+" ?");System.out.flush();
  if((System.in.read(buf)>0)&&
     (Character.toLowerCase((new String(buf)).charAt(0))=='y'))
  {
   System.out.println("Terminating Amazon instance.");
   ainst.terminate();
  }
 }
}
