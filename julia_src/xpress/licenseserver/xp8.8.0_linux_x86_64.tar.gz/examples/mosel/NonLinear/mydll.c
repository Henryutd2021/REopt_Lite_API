/*********************************************************************
   Mosel NL examples
   =================
   file mydll.c
   ````````````
   Implementation of the user function 'AreaInC' for polygon7.mos

   Compile this file to the dynamic library mydll.fct 
   using the provided makefile.

   (c) 2012 Fair Issac Corporation
       Creation: 2012
*********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifdef _WIN32
#define XPRS_CC __stdcall
#define XSLP_EXPORT __declspec(dllexport)
#else
#define XPRS_CC
#define XSLP_EXPORT
#endif

XSLP_EXPORT double XPRS_CC AreaInC(double *Values, int *nArg)
{
  int i;
  double Area;
  Area = 0;
  for (i=3;i<nArg[0];i=i+2) {
	Area = Area + Values[i-3]*Values[i-1]*sin(Values[i]-Values[i-2]);
  }
  return Area*0.5;
}

XSLP_EXPORT double XPRS_CC ComplexInC(double *Values, int *nArg, char *Names, double *RetArray)
{
  int i;
  double Area;
  Area = 0;
  for (i=3;i<nArg[0];i=i+2) {
	Area = Area + Values[i-3]*Values[i-1]*sin(Values[i]-Values[i-2]);
  }

  printf("WELCOME %s\n",Names);

  RetArray[0] = Area;

  return 0.0;
}


