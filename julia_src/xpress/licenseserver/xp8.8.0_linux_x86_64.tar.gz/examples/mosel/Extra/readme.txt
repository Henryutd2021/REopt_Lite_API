Extra Libraries Examples
========================

This directory contains examples that show how to use XPRD and bindrv libraries.

bdrv.c          generate and read data files using the 'bin:' data format
bdrv.java

fmgr.c          example using the XPRD library
fmgr.java       * start instances
                * retrieve system information
                * compile/load/run model
                * implement file manager to exchange data with model
                * send:receive Mosel events

piap.c          implementation of piapprox.mos in C/Java using XPRD
piap.java       (requires piapprox.mos)

