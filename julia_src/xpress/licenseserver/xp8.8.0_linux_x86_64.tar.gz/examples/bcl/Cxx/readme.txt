Xpress BCL examples readme.txt - 20 February, 2018

This directory contains three sets of examples illustrating the use of BCL:

     "IntrExpl": small introductory examples
     "AdvExpl" : advanced examples
     "UGExpl"  : examples from the Xpress BCL User Guide and Reference Manual
                 and from "Getting started with BCL" 


Building and running the BCL examples
-------------------------------------

i)   Make sure the environment variables XPRESSDIR, BCL and JDK are
     set to the installation directories of Xpress Optimizer, BCL and Java.
     Also, LD_LIBRARY_PATH must contain the paths of the dynamic 
     libaries.

ii)  To run a C example, go into one of the C examples directories, eg:
 
     cd ${BCL}/Examples/C/IntrExpl

     To run the file xbexpl, for example, type:

     make xbexpl
     xbexpl

     (Similarly for C++ examples in the Cxx subdirectory)

iii) To run a Java example, go into one of the Java examples directories, eg:
 
     cd ${BCL}/Examples/Java/IntrExpl

     To run the file xbexpl, for example, type:

     make xbexpl.class
     runjava xbexpl



