/********************************************************
  Xpress-BCL C++ Example Problems
  ===============================

  file foliocb.C
  ``````````````
  Modeling a MIP problem
  to perform portfolio optimization.

  Same model as in foliomip3.C.
  -- Defining an integer solution callback --

  (c) 2009 Fair Isaac Corporation
      author: S.Heipcke, May 2009, rev. Mar. 2011
********************************************************/

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include "xprb_cpp.h"
#include "xprs.h"

using namespace std;
using namespace ::dashoptimization;

#define MAXNUM 15                  // Max. number of different assets
#define MAXRISK 1.0/3              // Max. investment into high-risk values
#define MINREG 0.2                 // Min. investment per geogr. region
#define MAXREG 0.5                 // Max. investment per geogr. region
#define MAXSEC 0.25                // Max. investment per ind. sector
#define MAXVAL 0.2                 // Max. investment per share
#define MINVAL 0.1                 // Min. investment per share

#define DATAFILE "folio10.cdat"    // File with problem data
#define MAXENTRIES 10000


int NSHARES;                       // Number of shares
int NRISK;                         // Number of high-risk shares
int NREGIONS;                      // Number of geographical regions
int NTYPES;                        // Number of share types

double *RET;                       // Estimated return in investment
int *RISK;                         // High-risk values among shares
char **LOC;                        // Geogr. region of shares
char **SECT;                        // Industry sector of shares

char **SHARES_n;
char **REGIONS_n;
char **TYPES_n;

XPRBvar *frac;                     // Fraction of capital used per share
XPRBvar *buy;                      // 1 if asset is in portfolio, 0 otherwise

#include "readfoliodata.c_"

void XPRS_CC print_sol(XPRSprob oprob, void *vp);

int main(int argc, char **argv)
{
 int s,r,t;
 XPRBprob p("FolioMIP3");          // Initialize a new problem in BCL
 XPRBexpr Risk,Return,Cap,Num;
 XPRBexpr *MinReg, *MaxReg, *LimSec, LinkL, LinkU;

 readdata(DATAFILE);               // Data input from file

// Create the decision variables (including upper bounds for `frac')
 frac = new XPRBvar[NSHARES];
 buy = new XPRBvar[NSHARES];
 for(s=0;s<NSHARES;s++)
 {
  frac[s] = p.newVar("frac", XPRB_PL, 0, MAXVAL);
  buy[s] = p.newVar("buy", XPRB_BV);
 }

// Objective: total return
 for(s=0;s<NSHARES;s++) Return += RET[s]*frac[s];
 p.setObj(Return);                // Set the objective function

// Limit the percentage of high-risk values
 for(s=0;s<NRISK;s++) Risk += frac[RISK[s]];
 p.newCtr(Risk <= MAXRISK);

// Limits on geographical distribution
 MinReg = new XPRBexpr[NREGIONS];
 MaxReg = new XPRBexpr[NREGIONS];
 for(r=0;r<NREGIONS;r++)
 {
  for(s=0;s<NSHARES;s++)
   if(LOC[r][s]>0)
   {
    MinReg[r] += frac[s];
    MaxReg[r] += frac[s];
   }
  p.newCtr(MinReg[r] >= MINREG);
  p.newCtr(MaxReg[r] <= MAXREG);
 }

// Diversification across industry sectors
 LimSec = new XPRBexpr[NTYPES];
 for(t=0;t<NTYPES;t++)
 {
  for(s=0;s<NSHARES;s++)
   if(SECT[t][s]>0) LimSec[t] += frac[s];
  p.newCtr(LimSec[t] <= MAXSEC);
 }

// Spend all the capital
 for(s=0;s<NSHARES;s++) Cap += frac[s];
 p.newCtr(Cap == 1);

// Limit the total number of assets
 for(s=0;s<NSHARES;s++) Num += buy[s];
 p.newCtr(Num <= MAXNUM);

// Linking the variables
 for(s=0;s<NSHARES;s++)
 {
  p.newCtr(frac[s] <= MAXVAL*buy[s]);
  p.newCtr(frac[s] >= MINVAL*buy[s]);
 }

// Define an integer solution callback
 XPRSsetcbintsol(p.getXPRSprob(), print_sol, &p);

// Solve the problem
 p.setSense(XPRB_MAXIM);
 p.mipOptimize("");


 char *MIPSTATUS[] = {"not loaded", "not optimized", "LP optimized",
                      "unfinished (no solution)",
                      "unfinished (solution found)", "infeasible", "optimal",
                      "unbounded"};

 cout << "Problem status: " << MIPSTATUS[p.getMIPStat()] << endl;

 return 0;
}

/**************************Solution printing****************************/

void XPRS_CC print_sol(XPRSprob oprob, void *vp)
{
 int num,s;
 XPRBprob *bprob;

 bprob = (XPRBprob *)vp;
 bprob->beginCB(oprob);
 XPRSgetintattrib(oprob, XPRS_MIPSOLS, &num); // Get number of the solution

 bprob->sync(XPRB_XPRS_SOL);                  // Update BCL solution values
 cout << "Solution " << num << ": Total return: " << bprob->getObjVal() << endl;
 for(s=0;s<NSHARES;s++)
  if(buy[s].getSol()>0.5)
   cout << "  " << SHARES_n[s] << ": " << frac[s].getSol()*100 << "% (" <<
           buy[s].getSol() << ")" << endl;

 bprob->endCB();
}
