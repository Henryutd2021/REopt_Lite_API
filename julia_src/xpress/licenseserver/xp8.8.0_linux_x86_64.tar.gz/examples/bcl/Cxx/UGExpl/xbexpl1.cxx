/********************************************************
  Xpress-BCL C++ Example Problems
  ===============================

  file xbexpl1.cxx
  ````````````````
  BCL user guide example.
  Definition of variables and constraints, 
  variable arrays and SOS, followed by file output,
  solving and printing of solutions.

  (c) 2008 Fair Isaac Corporation
      author: S.Heipcke, Jan. 2000, rev. Mar. 2011
********************************************************/

#include <iostream>
#include "xprb_cpp.h"

using namespace std;
using namespace ::dashoptimization;

/**************************************************************************/
/* Define the following option to try out a problem formulation using     */
/* Special Ordered Sets:                                                  */
#undef SOS

/**************************************************************************/

#define NJ    4             /* Number of jobs */   
#define NT   10             /* Time limit */   

/**** DATA ****/
double DUR[] = {3,4,2,2};   /* Durations of jobs   */ 

XPRBvar start[NJ];          /* Start times of jobs  */ 
XPRBvar delta[NJ][NT];      /* Binaries for start times */  
XPRBvar z;                  /* Maximum completion time (makespan) */ 
XPRBsos set[NJ];            /* Sets regrouping start times for jobs */
 
void jobsModel(void);       /* Basic model formulation */
void jobsModelb(void);      /* Model using SOS */
void jobsSolve(void);       /* Solving and solution printing */

XPRBprob p("Jobs");         /* Initialize BCL and a new problem */ 
             
/*************************************************************************/

void jobsModel()
{
 XPRBexpr le;
 int j,t;

/****VARIABLES****/
                                /* Create start time variables */
 for(j=0;j<NJ;j++) start[j] = p.newVar("start");
 z = p.newVar("z",XPRB_PL,0,NT);  /* Declare the makespan variable */

 for(j=0;j<NJ;j++)              /* Declare binaries for each job  */
  for(t=0;t<(NT-DUR[j]+1);t++)
   delta[j][t] = p.newVar(XPRBnewname("delta%d%d",j+1,t+1),XPRB_BV);

/****CONSTRAINTS****/
 for(j=0;j<NJ;j++)              /* Calculate maximal completion time */
  p.newCtr("Makespan", start[j]+DUR[j] <= z);
  
 p.newCtr("Prec", start[0]+DUR[0] <= start[2]);
                                /* Precedence relation between jobs  */

 for(j=0;j<NJ;j++)              /* Linking start times and binaries  */ 
 { 
  le=0;
  for(t=0;t<(NT-DUR[j]+1);t++)  le += (t+1)*delta[j][t]; 
  p.newCtr(XPRBnewname("Link_%d",j+1), le == start[j]);
 } 
               
 for(j=0;j<NJ;j++)              /* One unique start time for each job  */
 { 
  le=0;
  for(t=0;t<(NT-DUR[j]+1);t++)  le += delta[j][t]; 
  p.newCtr(XPRBnewname("One_%d",j+1), le == 1);
 }      
              
/****OBJECTIVE****/
 p.setObj(p.newCtr("OBJ", z));  /* Define and set objective function */ 

/****BOUNDS****/
 for(j=0;j<NJ;j++) start[j].setUB(NT-DUR[j]+1); 
                                /* Upper bounds on start time variables */

/****OUTPUT****/
 p.print();                     /* Print out the problem definition */ 
 p.exportProb(XPRB_MPS,"expl1");  /* Output matrix to MPS file */ 
} 

/*************************************************************************/
void jobsSolve()             
{ 
 int j,t,statmip; 

#ifndef SOS
 for(j=0;j<NJ;j++)    
  for(t=0;t<NT-DUR[j]+1;t++)
   delta[j][t].setDir(XPRB_PR,10*(t+1)); 
            /* Give highest priority to variables for earlier start times */
#else
 for(j=0;j<NJ;j++)    
  set[j].setDir(XPRB_DN);        /* First branch downwards on sets */
#endif

 p.setSense(XPRB_MINIM);
 p.mipOptimize();                /* Solve the problem as MIP */
 statmip = p.getMIPStat();       /* Get the MIP problem status */    
              
 if((statmip == XPRB_MIP_SOLUTION) || (statmip == XPRB_MIP_OPTIMAL))
                                 /* An integer solution has been found */
 {  
  cout << "Objective: " << p.getObjVal() << endl; 
  for(j=0;j<NJ;j++) 
  {                              /* Print the solution for all start times */
   cout << start[j].getName() << ": " << start[j].getSol() << endl; 
   for(t=0;t<NT-DUR[j]+1;t++) 
    cout << delta[j][t].getName() << ": " << delta[j][t].getSol() << " ";
   cout << endl;
  }
 } 
}

/*************************************************************************/

int main(int argc, char **argv) 
{          
#ifndef SOS
  jobsModel();                   /* Basic problem definition */
#else
  jobsModelb();                  /* Formulation using SOS */
#endif
  jobsSolve();                   /* Solve and print solution */
  return 0;     
}

/*************************************************************************/

void jobsModelb(void)         /**** SOS-formulation ****/
{
 XPRBexpr le;
 int j,t;

/****VARIABLES****/
                                /* Create start time variables */
 for(j=0;j<NJ;j++) start[j] = p.newVar("start");
 z = p.newVar("z",XPRB_PL,0,NT);  /* Declare the makespan variable */

 for(j=0;j<NJ;j++)              /* Declare binaries for each job */
  for(t=0;t<(NT-DUR[j]+1);t++)
   delta[j][t] = p.newVar(XPRBnewname("delta%d%d",j+1,t+1),XPRB_PL,0,1);

/****CONSTRAINTS****/
 for(j=0;j<NJ;j++)              /* Calculate maximal completion time */
  p.newCtr("Makespan", start[j]+DUR[j] <= z);
  
 p.newCtr("Prec", start[0]+DUR[0] <= start[2]);
                                /* Precedence relation between jobs */

 for(j=0;j<NJ;j++)              /* Linking start times and binaries */ 
 { 
  le=0;
  for(t=0;t<(NT-DUR[j]+1);t++)  le += (t+1)*delta[j][t]; 
  p.newCtr(XPRBnewname("Link_%d",j+1), le == start[j]);
 } 
              
 for(j=0;j<NJ;j++)              /* One unique start time for each job */
 { 
  le=0;
  for(t=0;t<(NT-DUR[j]+1);t++)  le += delta[j][t]; 
  p.newCtr(XPRBnewname("One_%d",j+1), le == 1);
 }         
              
/****OBJECTIVE****/
 p.setObj(p.newCtr("OBJ", z));  /* Define and set objective function */ 

/****BOUNDS****/
 for(j=0;j<NJ;j++) start[j].setUB(NT-DUR[j]+1); 
                                /* Upper bounds on start time variables */

/****SETS****/
 for(j=0;j<NJ;j++)  
 {
  le=0;
  for(t=0;t<(NT-DUR[j]+1);t++)  le += (t+1)*delta[j][t];
  set[j] = p.newSos("sosj",XPRB_S1,le);
 } 

/****OUTPUT****/
 p.print();                     /* Print out the problem definition */ 
 p.exportProb(XPRB_MPS,"expl1");  /* Output matrix to MPS file */ 
} 

