BCL User Guide Examples
=======================

The examples in this directory are presented in their entirety or as
code fragments in the Xpress-BCL User Guide and Reference Manual,
in the part "Getting Started with BCL" of the "Getting Started with 
Xpress" manual, or in the "Evaluators Guide".

The BCL example files (*.cxx/*.cpp/*.C) are contained directly in this
directory. The corresponding Mosel (*.mos) files as well as any 
possibly required input data files are contained in the corresponding 
sub-directories of the Data subdirectory of the BCL Examples directory.

jobs
----
  Small scheduling problems, implemented in different ways.
  (Section 5.1 of Xpress-BCL User Guide and Reference Manual) 
xbexpl1.cxx: 
* using arrays of variables
* defining SOS
* setting branching directives
* file output
xbexpl1i.cxx:
* using index sets

infeas
------
  Small infeasible example that demonstrates user error handling.
xbexpl3.cxx: 
* defining the message and error callbacks
* changing BCL settings for printout and error handling
* raising C++ exceptions instead of the BCL default "exit on error"

trans
-----
  Transportation model.
xbexpl2.cxx:
* data input from file
* using index sets

contract
--------
  Contract allocation problem (see xbcontr.cxx in directory IntrExpl).
  (C++ version of Appendix B of Xpress-BCL User Guide and Reference Manual)
xbcontr1.cxx:
* combining BCL problem input with problem solving in Xpress-Optimizer
xbcontr2.cxx:
* using an Xpress-Optimizer solution callback with a BCL program

cutex
-----
  Defining cuts with BCL
xbcutex.cxx:
* using BCL cut functions
* using the Xpress-Optimizer cut manager callback with a BCL model

qpr12
-----
  Small Quadratic Programming example.
  (C++ version of Section 3.4 of Xpress-BCL User Guide and Reference Manual)
xbqpr12.cxx:
* defining a quadratic objective function
* defining ranged constraints
* defining free variables

airport
-------
  A QCQP example minimizing the total distance between a set of points.
xbairport.cxx:
* defining a QCQP model (quadratic objective, convex quadratic constraints)  

-----------------------------------------------------------------------

folio
-----

Examples from "Getting Started with BCL"
========================================
Chapter 10 "Inputting and Solving a Linear Programming problem"
* foliolp.cpp: modeling and solving a small LP problem
* folioinit.cpp: performing explicit initialization
* foliodata.cpp (data file: foliocpplp.dat): data input from file

Chapter 11 "Mixed Integer Programming"
* foliomip1.cpp: modeling and solving a small MIP problem (binary variables)
* foliomip2.cpp: modeling and solving a small MIP problem (semi-continuous
                 variables)

Chapter 12 "Quadratic Programming"
* folioqp.cpp (data file: foliocppqp.dat): modeling and solving a QP and 
                                           a MIQP problem
* folioqc.cpp (data file: foliocppqp.dat): modeling and solving a QCQP 

Chapter 13 "Heuristics"
* folioheur.cpp: heuristic solution of a MIP problem

Examples from "Advanced Evaluators Guide"
=========================================

foliomip3.cxx    - enlarged version of model foliomip.c from the
                   'Getting started' guide (more constraints, larger data set) 
		   employed by all examples in the directory
		   (to be used with data set folio10.dat or folio250.dat)

foliocb.cxx      - defining an integer solution callback

***Multiple MIP solutions***
foliosolpool.cxx - using the MIP solution pool
folioenumsol.cxx - using the solution enumerator

***Handling infeasibility***
folioinfeas.cxx  - handling infeasibility through deviation variables
folioiis.cxx     - retrieving IIS
foliorep.cxx     - using the built-in infeasibility repair functionality

-----------------------------------------------------------------------

Additional examples are located in the directories "IntrExpl" (introdcutory examples) and "AdvExpl" (more advanced examples).
