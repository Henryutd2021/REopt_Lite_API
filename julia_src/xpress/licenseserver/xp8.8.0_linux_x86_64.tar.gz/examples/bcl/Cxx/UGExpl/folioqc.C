/********************************************************
  Xpress-BCL C++ Example Problems
  ===============================

  file folioqc.C
  ``````````````
  Modeling a small QCQP problem
  to perform portfolio optimization.
  -- Maximize return with limit on variance ---

  (c) 2008 Fair Isaac Corporation
      author: S.Heipcke, July 2008, rev. Mar. 2011
********************************************************/

#include <iostream>
#include <cstdio>
#include "xprb_cpp.h"

using namespace std;
using namespace ::dashoptimization;

#define DATAFILE XPRBDATAPATH "/GS/foliocppqp.dat"

#define MAXVAR 0.55                // Max. allowed variance

#define NSHARES 10                 // Number of shares
#define NNA 4                      // Number of North-American shares

double RET[] = {5,17,26,12,8,9,7,6,31,21};  // Estimated return in investment
int NA[] = {0,1,2,3};              // Shares issued in N.-America
double VAR[NSHARES][NSHARES];      // Variance/covariance matrix of
                                   // estimated returns

int main(int argc, char **argv)
{
 int s,t;
 XPRBprob p("FolioQC");            // Initialize a new problem in BCL
 XPRBexpr Na,Return,Cap,Variance;
 XPRBvar frac[NSHARES];            // Fraction of capital used per share
 FILE *datafile;

// Read `VAR' data from file
 datafile=fopen(DATAFILE,"r");
 for(s=0;s<NSHARES;s++)
  XPRBreadarrlinecb(XPRB_FGETS, datafile, 200, "g ", VAR[s], NSHARES);
 fclose(datafile);

// Create the decision variables
 for(s=0;s<NSHARES;s++)
  frac[s] = p.newVar(XPRBnewname("frac(%d)",s+1), XPRB_PL, 0, 0.3);

// Objective: total return
 for(s=0;s<NSHARES;s++) Return += RET[s]*frac[s];
 p.setObj(Return);                 // Set the objective function

// Minimum amount of North-American values
 for(s=0;s<NNA;s++) Na += frac[NA[s]];
 p.newCtr(Na >= 0.5);

// Spend all the capital
 for(s=0;s<NSHARES;s++) Cap += frac[s];
 p.newCtr(Cap == 1);

// Limit variance
 for(s=0;s<NSHARES;s++)
  for(t=0;t<NSHARES;t++) Variance += VAR[s][t]*frac[s]*frac[t];
 p.newCtr(Variance <= MAXVAR);

// Solve the problem
 p.setSense(XPRB_MAXIM);
 p.lpOptimize("");

// Solution printing
 cout << "With a max. variance of " << MAXVAR << " total return is " <<
         p.getObjVal() << endl;
 for(s=0;s<NSHARES;s++)
  cout << s << ": " << frac[s].getSol()*100 << "%" << endl;

 return 0;
}

