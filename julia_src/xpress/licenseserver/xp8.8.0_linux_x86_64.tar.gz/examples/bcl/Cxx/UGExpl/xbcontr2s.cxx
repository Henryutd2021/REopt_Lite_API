/********************************************************
  Xpress-BCL C++ Example Problems
  ===============================

  file xbcontr2s.cxx
  ``````````````````
  Contract allocation example.
  Combining BCL problem input with problem solving 
  and callbacks in Xpress-Optimizer.
  -- Single MIP thread --

  (c) 2008 Fair Isaac Corporation
      author: S.Heipcke, Jan. 2000, rev. Mar. 2011
********************************************************/

#include <iostream>
#include "xprb_cpp.h"
#include "xprs.h"

using namespace std;
using namespace ::dashoptimization;

#define District 6               /* Number of districts */
#define Contract 10              /* Number of contracts */

/**** DATA ****/
int OUTPUT[] = {50, 40, 10, 20, 70, 50};    /* Max. output per district */
int COST[]   = {50, 20, 25, 30, 45, 40};    /* Cost per district */
int VOLUME[]   = {20, 10, 30, 15, 20, 30, 10, 50, 10, 20};  
                                 /* Volume of contracts */
 
/***********************************************************************/

void XPRS_CC printsolution(XPRSprob oprob, void *vp)
{
 int num, d, c;
 XPRBprob *bprob;
 XPRBvar y;
 
 bprob = (XPRBprob *)vp;
 XPRSgetintattrib(oprob, XPRS_MIPSOLS, &num); /* Get number of the solution */
 bprob->sync(XPRB_XPRS_SOL);                  /* Update BCL solution values */
 cout << "Solution " << num << ": Objective value: " << bprob->getObjVal() << endl; 

 for(d=0;d<District;d++)
  for(c=0;c<Contract;c++)
  {
   y = bprob->getVarByName(XPRBnewname("q_d%dc%d",d+1,c+1));
   if( (y.getColNum()>-1) && (y.getSol() != 0))
    cout << y.getName() << ": " << y.getSol() << endl; 
  }
}

/***********************************************************************/

int main(int argc, char **argv)
{
 int d,c;
 XPRBexpr l1,l2,lobj;
 XPRBvar x[District][Contract];  /* Variables indicating whether a project 
                                    is chosen */
 XPRBvar y[District][Contract];  /* Quantities allocated to contractors */
 XPRBprob p("Contr2");           /* Initialize a new problem in BCL */
 
/**** VARIABLES ****/
 for(d=0;d<District;d++)
  for(c=0;c<Contract;c++)
  {
   x[d][c] = p.newVar(XPRBnewname("x_d%dc%d",d+1,c+1),XPRB_BV);
   y[d][c] = p.newVar(XPRBnewname("q_d%dc%d",d+1,c+1),XPRB_SC,0,OUTPUT[d]);
   y[d][c].setLim(5);
  } 

/****OBJECTIVE****/
 for(d=0;d<District;d++)
  for(c=0;c<Contract;c++)
   lobj += COST[d]*y[d][c];   
     
 p.setObj(p.newCtr("OBJ",lobj));       /* Set the objective function */
 
/**** CONSTRAINTS ****/
 for(c=0;c<Contract;c++)
 {
  l1=0;
  l2=0;  
  for(d=0;d<District;d++)
  {
   l1 += y[d][c];
   l2 += x[d][c];
  }
  p.newCtr("Size", l1 >= VOLUME[c]);   /* "Size": cover the required volume */
  p.newCtr("Min", l2 >= 2 ); 	/* "Min": at least 2 districts per contract */
 }
 
 for(d=0;d<District;d++)        /* Do not exceed max. output of any district */
 {
  l1=0;
  for(c=0;c<Contract;c++)
   l1 += y[d][c];
  p.newCtr("Output", l1 <= OUTPUT[d]);
 } 
 
 for(d=0;d<District;d++)        /* If a contract is allocated to a district,
                                   then at least 1 unit is allocated to it */
  for(c=0;c<Contract;c++)
   p.newCtr("XY", x[d][c] <= y[d][c]);

/****SOLVING + OUTPUT****/
 XPRSsetintcontrol(p.getXPRSprob(), XPRS_MIPTHREADS, 1);
    /* Desactivate parallel MIP (for synchronization of BCL and Optimizer) */
 XPRSsetcbintsol(p.getXPRSprob(), printsolution, &p);
                                /* Define an integer solution callback */
 p.mipOptimize("");             /* Solve the MIP problem */

 return 0;
} 
