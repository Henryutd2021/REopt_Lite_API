/********************************************************
  Xpress-BCL C++ Example Problems
  ===============================

  file xbqpr12.cxx
  ````````````````
  Small Quadratic Programming example.
       minimize x1 + x1^2 +2x1x2 +2x2^2 +x4^2
       s.t. C1:  x1 +2x2 -4x4 >= 0
            C2: 3x1 -2x3 - x4 <= 100
            C3: 10 <= x1 +3x2 +3x3 -2x4 <= 30
            0<=x1<=20
            0<=x2,x3
            x4 free

  (c) 2008 Fair Isaac Corporation
      author: S.Heipcke, Jan. 2000, rev. Mar. 2011
********************************************************/

#include <iostream>
#include "xprb_cpp.h"

using namespace std;
using namespace ::dashoptimization;

#define NXPRBvar 4

/***********************************************************************/

int main(int argc, char **argv)
{
 XPRBctr c;
 XPRBexpr le, qobj;
 XPRBvar x[NXPRBvar];
 int i;
 XPRBprob p("QPr12");     	/* Initialize a new problem in BCL */

/**** VARIABLES ****/
 x[0] = p.newVar("x1", XPRB_PL, 0, 20);
 x[1] = p.newVar("x2");
 x[2] = p.newVar("x3");
 x[3] = p.newVar("x4", XPRB_PL, -XPRB_INFINITY, XPRB_INFINITY);

/****OBJECTIVE****/
		                  /* Define the objective function */
 qobj = x[0] + sqr(x[0])  +2*x[0]*x[1]  + 2*sqr(x[1])  + sqr(x[3]);
 p.setObj(qobj);
 
/**** CONSTRAINTS ****/
 p.newCtr("C1", x[0] + 2*x[1] - 4*x[3] >= 0);
 p.newCtr("C2", 3*x[0] - 2*x[2] -x[3] <= 100);
 c = p.newCtr("C3", x[0] + 3*x[1] + 3*x[2] - 2*x[3] );
 c.setRange(10,30);
   
/****SOLVING + OUTPUT****/
 p.print();			  /* Print out the problem definition */
 p.exportProb(XPRB_MPS,"QPr12");  /* Output the matrix in MPS format */
 p.exportProb(XPRB_LP,"QPr12");   /* Output the matrix in LP format */
  
 p.setSense(XPRB_MINIM);      	  /* Choose the sense of the optimization */   
 p.lpOptimize("");                /* Solve the QP-problem */

 cout << "Objective function value: " << p.getObjVal() << endl;
 for(i=0;i<NXPRBvar;i++)
  cout << x[i].getName() << ": " << x[i].getSol() << ", ";
 cout << endl;
 
 return 0;
}
