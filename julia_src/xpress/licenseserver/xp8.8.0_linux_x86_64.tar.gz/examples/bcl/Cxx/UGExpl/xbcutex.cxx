/********************************************************
  Xpress-BCL C++ Example Problems
  ===============================

  file xbcutex.cxx
  ````````````````
  Simplified version of xbexpl1.cxx showing how 
  to define cuts with BCL.

  (c) 2008 Fair Isaac Corporation
      author: S.Heipcke, 2005, rev. Mar. 2011
********************************************************/

#include <iostream>
#include "xprb_cpp.h"
#include "xprs.h"

using namespace std;
using namespace ::dashoptimization;

#define NJ    4             /* Number of jobs */   
#define NT   10             /* Time limit */   

/**** DATA ****/
double DUR[] = {3,4,2,2};   /* Durations of jobs   */ 

XPRBvar start[NJ];          /* Start times of jobs  */ 
XPRBvar delta[NJ][NT];      /* Binaries for start times */  
XPRBvar z;                  /* Maximum completion time (makespan) */ 
 
void jobsModel(void);       /* Basic model formulation */
void jobsSolve(void);       /* Solving and solution printing */

XPRBprob p("Jobs");         /* Initialize BCL and a new problem */ 
             
/***********************************************************************/

int XPRS_CC usrcme(XPRSprob oprob, void* vd)
{
 XPRBcut ca[2];
 int num;
 int i=0;
 XPRBprob *bprob;

/* In terms of an example, we add a few additional constraints (without
   any relation to the original problem) at the second node of the MIP
   search tree. These constraints/cuts are applied at this node and all 
   its child nodes. */
 
 bprob = (XPRBprob*)vd;
 bprob->beginCB(oprob);
 XPRSgetintattrib(oprob, XPRS_NODES, &num);
 if(num == 2) 
 {
  ca[0] = bprob->newCut(start[1]+2 <= start[0], 2); 
  ca[1] = bprob->newCut(4*start[2] - 5.3*start[3] <= -17, 2);
  cout << "Adding constraints:" << endl;
  for(i=0;i<2;i++) ca[i].print();
  if(bprob->addCuts(ca,2)) cout << "Problem with adding cuts." << endl;
 }
 bprob->endCB();
 return 0;                      /* Call this function once per node */
}

/*************************************************************************/

void jobsModel()
{
 XPRBexpr le;
 int j,t;

/****VARIABLES****/
                                /* Create start time variables */
 for(j=0;j<NJ;j++) start[j] = p.newVar("start");
 z = p.newVar("z",XPRB_PL,0,NT);  /* Declare the makespan variable */

 for(j=0;j<NJ;j++)              /* Declare binaries for each job  */
  for(t=0;t<(NT-DUR[j]+1);t++)
   delta[j][t] = p.newVar(XPRBnewname("delta%d%d",j+1,t+1),XPRB_BV);

/****CONSTRAINTS****/
 for(j=0;j<NJ;j++)              /* Calculate maximal completion time */
  p.newCtr("Makespan", start[j]+DUR[j] <= z);
  
 p.newCtr("Prec", start[0]+DUR[0] <= start[2]);
                                /* Precedence relation between jobs  */

 for(j=0;j<NJ;j++)              /* Linking start times and binaries  */ 
 { 
  le=0;
  for(t=0;t<(NT-DUR[j]+1);t++)  le += (t+1)*delta[j][t]; 
  p.newCtr(XPRBnewname("Link_%d",j+1), le == start[j]);
 } 
               
 for(j=0;j<NJ;j++)              /* One unique start time for each job  */
 { 
  le=0;
  for(t=0;t<(NT-DUR[j]+1);t++)  le += delta[j][t]; 
  p.newCtr(XPRBnewname("One_%d",j+1), le == 1);
 }      
              
/****OBJECTIVE****/
 p.setObj(p.newCtr("OBJ", z));  /* Define and set objective function */ 

/****BOUNDS****/
 for(j=0;j<NJ;j++) start[j].setUB(NT-DUR[j]+1); 
                                /* Upper bounds on start time variables */
} 

/*************************************************************************/

void jobsSolve()             
{ 
 int j,t,statmip; 
 XPRSprob oprob;

 oprob = p.getXPRSprob();
 XPRSsetintcontrol(oprob,XPRS_HEURSTRATEGY,0);
 XPRSsetintcontrol(oprob,XPRS_CUTSTRATEGY,0);
                             /* Switch heuristics and cut generation off:
                                otherwise this problem is solved in the
                                first node of the MIP search tree */

 p.setCutMode(1);                /* Enable the cut mode */
 XPRSsetcbcutmgr(oprob,usrcme,&p);

 p.setSense(XPRB_MINIM);
 p.mipOptimize("");              /* Solve the problem as MIP */
 statmip = p.getMIPStat();       /* Get the MIP problem status */    
              
 if((statmip == XPRB_MIP_SOLUTION) || (statmip == XPRB_MIP_OPTIMAL))
                                 /* An integer solution has been found */
 {  
  cout << "Objective: " << p.getObjVal() << endl; 
  for(j=0;j<NJ;j++) 
  {                              /* Print the solution for all start times */
   cout << start[j].getName() << ": " << start[j].getSol() << endl; 
   for(t=0;t<NT-DUR[j]+1;t++) 
    cout << delta[j][t].getName() << ": " << delta[j][t].getSol() << " ";
   cout << endl;
  }
 } 
}

/*************************************************************************/

int main(int argc, char **argv) 
{          
  jobsModel();                   /* Basic problem definition */
  jobsSolve();                   /* Solve and print solution */
  return 0;     
}


