/********************************************************
  Xpress-BCL C++ Example Problems
  ===============================

  file folioqp.C
  ``````````````
  Modeling a small QP problem
  to perform portfolio optimization.
   -- 1. QP: minimize variance
      2. MIQP: limited number of assets ---

  (c) 2008 Fair Isaac Corporation
      author: S.Heipcke, Aug. 2003, rev. Mar. 2011
********************************************************/

#include <iostream>
#include <cstdio>
#include "xprb_cpp.h"

using namespace std;
using namespace ::dashoptimization;

#define DATAFILE XPRBDATAPATH "/GS/foliocppqp.dat"

#define TARGET 9                   // Target yield
#define MAXNUM 4                   // Max. number of different assets

#define NSHARES 10                 // Number of shares
#define NNA 4                      // Number of North-American shares

double RET[] = {5,17,26,12,8,9,7,6,31,21};  // Estimated return in investment
int NA[] = {0,1,2,3};              // Shares issued in N.-America
double VAR[NSHARES][NSHARES];      // Variance/covariance matrix of
                                   // estimated returns

int main(int argc, char **argv)
{
 int s,t;
 XPRBprob p("FolioQP");            // Initialize a new problem in BCL
 XPRBexpr Na,Return,Cap,Num,Variance;
 XPRBvar frac[NSHARES];            // Fraction of capital used per share
 XPRBvar buy[NSHARES];             // 1 if asset is in portfolio, 0 otherwise
 FILE *datafile;

// Read `VAR' data from file
 datafile=fopen(DATAFILE,"r");
 for(s=0;s<NSHARES;s++)
  XPRBreadarrlinecb(XPRB_FGETS, datafile, 200, "g ", VAR[s], NSHARES);
 fclose(datafile);

// **** First problem: unlimited number of assets ****

// Create the decision variables
 for(s=0;s<NSHARES;s++)
  frac[s] = p.newVar(XPRBnewname("frac(%d)",s+1), XPRB_PL, 0, 0.3);

// Objective: mean variance
 for(s=0;s<NSHARES;s++)
  for(t=0;t<NSHARES;t++) Variance += VAR[s][t]*frac[s]*frac[t];
 p.setObj(Variance);                 // Set the objective function

// Minimum amount of North-American values
 for(s=0;s<NNA;s++) Na += frac[NA[s]];
 p.newCtr(Na >= 0.5);

// Spend all the capital
 for(s=0;s<NSHARES;s++) Cap += frac[s];
 p.newCtr(Cap == 1);

// Target yield
 for(s=0;s<NSHARES;s++) Return += RET[s]*frac[s];
 p.newCtr(Return >= TARGET);

// Solve the problem
 p.setSense(XPRB_MINIM);
 p.lpOptimize("");

// Solution printing
 cout << "With a target of " << TARGET << " minimum variance is " <<
         p.getObjVal() << endl;
 for(s=0;s<NSHARES;s++)
  cout << s << ": " << frac[s].getSol()*100 << "%" << endl;

// **** Second problem: limit total number of assets ****

// Create the decision variables
 for(s=0;s<NSHARES;s++)
  buy[s] = p.newVar(XPRBnewname("buy(%d)",s+1), XPRB_BV);

// Limit the total number of assets
 for(s=0;s<NSHARES;s++) Num += buy[s];
 p.newCtr(Num <= MAXNUM);

// Linking the variables
 for(s=0;s<NSHARES;s++) p.newCtr(frac[s] <= buy[s]);

// Solve the problem
 p.mipOptimize("");

// Solution printing
 cout << "With a target of " << TARGET << " and at most " << MAXNUM <<
         " assets, minimum variance is " << p.getObjVal() << endl;
 for(s=0;s<NSHARES;s++)
  cout << s << ": " << frac[s].getSol()*100 << "% (" << buy[s].getSol()
       << ")" << endl;

 return 0;
}

