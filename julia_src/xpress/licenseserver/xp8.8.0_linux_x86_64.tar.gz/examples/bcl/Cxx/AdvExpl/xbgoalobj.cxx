/********************************************************
  Xpress-BCL C++ Example Problems
  ===============================

  file xbgoalobj.cxx
  ``````````````````
  Archimedian and pre-emptive goal programming
  using objective functions.

  (c) 2008 Fair Isaac Corporation
      author: S.Heipcke, 2005, rev. Mar. 2011
********************************************************/

#include <iostream>
#include <cmath>
#include <cstring>
#include "xprb_cpp.h"
#include "xprs.h"

using namespace std;
using namespace ::dashoptimization;

#define NGOALS 3

// **** Data ****
const char *Type[] = {"perc", "abs", "perc"};
const char *Sense[] = {"max", "min", "max"};
double Weight[] = {100, 1, 0.1};
double Deviation[] = {10, 4, 20};

void modelgo()
{
 XPRBvar x,y;
 XPRBctr goalCtr[NGOALS], aCtr;
 double Target[NGOALS];
 XPRBexpr goal[NGOALS], wobj;
 XPRBprob *prob;
 int i,g;

 prob = new XPRBprob("Goal");

 // Adding the variables
 x = prob->newVar("x",XPRB_PL);
 y = prob->newVar("y",XPRB_PL);

 // Adding a constraint
 aCtr = prob->newCtr("Limit", 42*x + 13*y <= 100);

 // Goals
 goal[0] = 5*x +  2*y - 20;
 goal[1] = -3*x + 15*y - 48;
 goal[2] = 1.5*x + 21*y - 3.8;
 for(g=0;g<NGOALS;g++) 
  goalCtr[g] = prob->newCtr(XPRBnewname("Goal%d",(g+1)), goal[g]);

 // **** Archimedian GP ****
 cout << "Archimedian:" << endl;
 wobj = 0;
 for(g=0;g<NGOALS;g++) 
 {
  if (strcmp(Sense[g],"max")==0)
   wobj -= Weight[g]*goal[g];
  else
   wobj += Weight[g]*goal[g]; 
 } 
 prob->setObj(wobj);
 XPRSsetintcontrol(prob->getXPRSprob(),XPRS_OUTPUTLOG, 0);
 prob->lpOptimize("");

 // Solution printout
 cout << " Solution: x: " << x.getSol() << ", y: " << y.getSol() << endl;
 cout <<" Goal   Target     Value" << endl;
 for(g=0;g<NGOALS;g++) 
   cout << "  " << g+1 << "       " << Sense[g] << "     " << (goalCtr[g].getAct() - goalCtr[g].getRHS()) << endl; 
  
  
 // **** Prememptive GP ****  
 cout << "Prememptive:" << endl;
 i=-1;
 while (i<NGOALS-1) 
 {
  i+=1;
  if (strcmp(Sense[i],"max")==0) 
  {
   prob->setObj(goal[i]);
   prob->setSense(XPRB_MAXIM);
   prob->lpOptimize("");
   if (prob->getLPStat() != XPRB_LP_OPTIMAL)
   {
    cout << "Cannot satisfy goal " << i+1 << endl;
    break;
   }
   else
   {
    Target[i]=prob->getObjVal(); 
    if (strcmp(Type[i],"perc")==0)
     Target[i]-= abs(Target[i])*Deviation[i]/100;
    else
     Target[i]-= Deviation[i];
    if (i<NGOALS-1) goalCtr[i] -= Target[i];
    goalCtr[i].setType(XPRB_G); 
   }
  }
  else
  {
   prob->setObj(goal[i]);
   prob->setSense(XPRB_MINIM);
   prob->lpOptimize("");
   if (prob->getLPStat() != XPRB_LP_OPTIMAL)
   {
    cout << "Cannot satisfy goal " << i+1 << endl;
    break;
   }
   else
   {
    Target[i]=prob->getObjVal(); 
    if (strcmp(Type[i],"perc")==0)
     Target[i]+= abs(Target[i])*Deviation[i]/100;
    else
     Target[i]+= Deviation[i];
    if (i<NGOALS-1) goalCtr[i] -= Target[i];
    goalCtr[i].setType(XPRB_L);
   } 
  }
  cout << "Solution(" << i+1 << "):  x: " << x.getSol() << ", y: " << y.getSol() << endl;
 }

 // Solution printout
 cout << " Goal       Target         Value" << endl;
  for(g=0;g<=i;g++) 
  {
   cout << "  " << g+1 << "     " << (goalCtr[g].getType()==XPRB_G?" >=  ":" <=  ") << Target[g];
   if(g==NGOALS-1) 
    cout << "     " << prob->getObjVal() << endl;
   else   
    cout << "     " << (goalCtr[g].getAct() - goalCtr[g].getRHS()) + Target[g] << endl;
  }

 delete prob;
}

int main(int argc, char **argv)
{
 if (XPRB::init()) return 1;

 modelgo();
 XPRB::finish();

 return 0;
}
