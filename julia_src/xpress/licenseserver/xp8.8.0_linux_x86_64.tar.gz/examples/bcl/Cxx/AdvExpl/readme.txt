Advanced BCL Examples
=====================

This directory contains a selection of examples that demonstrate
more advanced uses of Xpress-BCL. The examples show how to implement solution heuristics with BCL. 

cutstk
------
  Column generation for a cutting stock problem.
xbcutstk.cxx:
* iteratively adding new variables
* basis in/output
* working with subproblems

els
---
  An economic lot-sizing (ELS) problem solved by cut&branch and
  branch&cut heuristics.
xbels.cxx:
* iteratively adding new constraints
* basis in/output
xbelsc.cxx:
* using the Xpress-Optimizer cut manager callback with BCL cut functions

fixbv
-----
  Implementing a binary fixing heuristic for the complete Coco Problem 
  (see also xbcoco.cxx in directory IntrExpl).
xbfixbv.cxx
* changing bounds directly in the Optimizer
* basis in/output
xbfixbvls.cxx:
* loading a MIP solution

goalobj
-------
  Archimedian and pre-emptive goal programming using objective functions.
xbgoalobj.cxx:
* constraint access functions
* repeated solving with modified objectives

recurs
------
  A non-linear problem modeled as a successive linear programming (SLP) 
  model. (SLP is also known as 'recursion'.)
xbrecurs.cxx:
* iteratively changing constraint coefficients
* basis in/output

d1wagon2
--------
  Load balancing of train wagons using heuristic solution as start
  solution for MIP.
xbd1wagon2.cxx:
* simple MIP problem  
* heuristic to find start MIP sol
* using addmipsol and the solnotify callback
    
-----------------------------------------------------------------------

Additional examples are located in the directories "IntrExpl" (introductory examples) and "UGExpl" (examples from the Xpress-BCL User Guide and Reference Manual).
