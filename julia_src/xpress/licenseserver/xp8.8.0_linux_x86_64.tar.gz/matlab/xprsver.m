function xprsver
%%
% Purpose
% Display version number for Xpress
%
% Syntax
%    xprsver
%
% Description
% xprsver prints the version and release number for the Xpress software
% currently running.
%
% Examples
% Display the version:
%     xprsver
% MATLAB display:
%     FICO Xpress Optimizer 64-bit v21.00.02 (Hyper capacity)
%     (c) Copyright Fair Isaac Corporation 2010

% ---------------------------------------------------------------------------
% File: xprsver.m
% ---------------------------------------------------------------------------
% Published by Fair Isaac Corporation
% (c) Copyright Fair Isaac Corporation 2010-2012. All rights reserved.